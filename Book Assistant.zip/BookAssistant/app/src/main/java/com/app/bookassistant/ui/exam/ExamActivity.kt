package com.app.bookassistant.ui.exam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.app.bookassistant.R

class ExamActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exam)
    }
}
