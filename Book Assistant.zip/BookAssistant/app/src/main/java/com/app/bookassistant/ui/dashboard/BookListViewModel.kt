package com.app.bookassistant.ui.dashboard

class BookListViewModel {

}